This project contains version 3.1 of the Mongoose web server project, as 
found at http://code.google.com/p/mongoose.

It contains the code for version 3.1 as of 26-May-2011 (revision 0ca751520abf).
It contains an additional change in pthread_cond_broadcast() [~line 865] to 
improve stability when running a debug build.